# Conquest2022 Mentor Matching Algorithm
Contains everything pertaining to the Conquest 2022 Mentor Matching Algorithm

AlgoDesign6 uses Matching Scores to Allot Mentors

AlgoDesign8 uses Startup Preferences to Allot Mentors

Both AlgoDesign6 and AlgoDesign8 were used to provide Startups with a Mix of Mentors of their preference and those which have a high overlap score.
